function result = run_4watcher_accel_fusion_EKF(dim,makePlots,simulationTime,dt,seed)
%RUN_4WATCHER_ACCEL_FUSION_EKF Angle-only local EKFs and acceleration fusion.
%
% PURPOSE
% -------
% Simulate four independent local EKFs that estimate the same target state
%
%   x_k = [r_k; v_k; a_k]
%
% from angle-only measurements:
%
%   dim = 2: one scalar bearing angle per watcher,
%   dim = 3: azimuth and elevation per watcher.
%
% Each local EKF produces the filtered point estimate
%
%   aHat_i(k|k) = E[a_k | z_i(1:k)]
%
% of the current acceleration. Thus, aHat_i(k|k) is one vector at time k,
% but it is conditioned on the complete local measurement history up to k.
%
% The fusion rule uses the same prior predicted LOS direction used to build
% the EKF measurement Jacobian:
%
%   uHat_i^-(k) = (rHat_i^-(k)-r_wi)/||rHat_i^-(k)-r_wi||,
%   Pperp_i(k)  = I-uHat_i^-(k)uHat_i^-(k)^T.
%
% Watcher i shares the transverse directional constraint
%
%   q_i(k) = alpha_i Pperp_i(k) aHat_i(k|k).
%
% The fused acceleration point estimate is
%
%   aHat_f(k) = [sum_i alpha_i Pperp_i(k)]^dagger sum_i q_i(k),
%
% where dagger denotes the Moore-Penrose pseudoinverse. In this baseline,
% alpha_i = 1 for all watchers, so all local transverse constraints have
% equal scalar confidence; the directions still differ through Pperp_i.
%
% IMPORTANT
% ---------
% - The fusion rule does not use the true target position or true range.
% - The measured angles are used in each EKF innovation.
% - The fusion projector uses the prior predicted LOS, not the noisy measured
%   LOS, to remain consistent with the EKF linearization geometry.
% - The true trajectory is used only to generate measurements and evaluate
%   estimation errors.
%
% INPUTS
% ------
% dim             Spatial dimension: 2 or 3.
% makePlots       Logical flag for plotting.
% simulationTime  Total simulation duration [s].
% dt              Sampling interval [s].
% seed            Random-number seed.
%
% OUTPUT
% ------
% result          Structure containing truth, local filtered point estimates,
%                 shared transverse constraints, fused point estimates,
%                 geometry diagnostics, and RMSE summaries.

if nargin < 2 || isempty(makePlots),      makePlots = true; end
if nargin < 3 || isempty(simulationTime), simulationTime = 40; end
if nargin < 4 || isempty(dt),             dt = 0.05; end
if nargin < 5 || isempty(seed),           seed = 7 + dim; end

validateattributes(dim,{'numeric'},{'scalar','integer'});
if ~ismember(dim,[2,3])
    error('dim must be 2 or 3.');
end
validateattributes(simulationTime,{'numeric'},{'scalar','positive','finite'});
validateattributes(dt,{'numeric'},{'scalar','positive','finite'});
validateattributes(seed,{'numeric'},{'scalar','integer','nonnegative'});

rng(seed);

%% Configuration
Nw = 4;
t  = (0:dt:simulationTime).';
N  = numel(t);

if dim == 2
    % Symmetric planar watcher geometry.
    pWatcher = [ ...
       -30,  30,   0,   0;
         0,   0, -30,  30];
else
    % Noncoplanar tetrahedral geometry. The columns all have norm 30.
    d = 30/sqrt(3);
    pWatcher = d*[ ...
         1,  1, -1, -1;
         1, -1,  1, -1;
         1, -1, -1,  1];
end

sigmaBearing = deg2rad(0.2);
sigmaAz      = deg2rad(0.2);
sigmaEl      = deg2rad(0.2);

% Equal-confidence baseline. Later, alphaWatcher can be made time-varying.
alphaWatcher = ones(Nw,1);
relativeRankTol = 1e-10;

%% Smooth unknown truth acceleration
aTrue = zeros(dim,N);

for k = 1:N
    tk = t(k);

    if dim == 2
        aTrue(:,k) = 10*[ ...
            0.025*sin(0.35*tk) + 0.015*cos(0.13*tk);
            0.020*cos(0.31*tk) - 0.010*sin(0.19*tk)];
    else
        aTrue(:,k) = 10*[ ...
            0.025*sin(0.35*tk) + 0.012*cos(0.11*tk);
            0.020*cos(0.31*tk) - 0.010*sin(0.19*tk);
            0.018*sin(0.27*tk + 0.6) + 0.009*cos(0.15*tk)];
    end
end

%% Integrate truth trajectory
rTrue = zeros(dim,N);
vTrue = zeros(dim,N);

for k = 1:N-1
    vTrue(:,k+1) = vTrue(:,k) + aTrue(:,k)*dt;
    rTrue(:,k+1) = rTrue(:,k) + vTrue(:,k)*dt ...
        + 0.5*aTrue(:,k)*dt^2;
end

%% Constant-acceleration local EKF model
n = 3*dim;

F = [ ...
    eye(dim),        dt*eye(dim), 0.5*dt^2*eye(dim);
    zeros(dim),      eye(dim),    dt*eye(dim);
    zeros(dim),      zeros(dim),  eye(dim)];

% Acceleration random-walk increment model.
G = [ ...
    0.5*dt^2*eye(dim);
    dt*eye(dim);
    eye(dim)];

sigmaAccelIncrement = 2e-3;
Q = sigmaAccelIncrement^2*(G*G.');

P0 = diag([ ...
    50^2*ones(1,dim), ...
    0.1^2*ones(1,dim), ...
    0.05^2*ones(1,dim)]);

%% Local-filter and fusion storage
xhat       = zeros(n,N,Nw);
Plog       = zeros(n,n,Nw,N);
aLocal     = zeros(dim,N,Nw);  % aHat_i(k|k): local filtered point estimate
uMeasLog   = zeros(dim,N,Nw);
uPredLog   = zeros(dim,N,Nw);  % prior predicted LOS used by the EKF Jacobian

omegaLog   = zeros(dim,dim,Nw,N); % alpha_i Pperp_i
BLog       = zeros(dim,dim,Nw,N); % normalized matrix contribution
qSharedLog = zeros(dim,N,Nw);     % alpha_i Pperp_i aHat_i(k|k)

geometrySum       = zeros(dim,dim,N);
geometryCondition = nan(1,N);
geometryRank      = zeros(1,N);
geometryEigenvalues = zeros(dim,N);

for j = 1:Nw
    xhat(:,1,j) = [ ...
        rTrue(:,1) + 20*randn(dim,1);
        0.1*randn(dim,1);
        0.05*randn(dim,1)];

    Plog(:,:,j,1) = P0;
    aLocal(:,1,j) = xhat(2*dim+(1:dim),1,j);
end

%% Initial measurements and predicted LOS
for j = 1:Nw
    rhoTrue0 = rTrue(:,1) - pWatcher(:,j);

    if dim == 2
        bearingTrue0 = atan2(rhoTrue0(2),rhoTrue0(1));
        z0 = wrapAngle(bearingTrue0 + sigmaBearing*randn);
        uMeasLog(:,1,j) = [cos(z0); sin(z0)];
    else
        [azTrue0,elTrue0] = cartesianToAzEl(rhoTrue0);
        zAz0 = wrapAngle(azTrue0 + sigmaAz*randn);
        zEl0 = clampElevation(elTrue0 + sigmaEl*randn);
        uMeasLog(:,1,j) = azElToUnitLOS(zAz0,zEl0);
    end

    rh0 = xhat(1:dim,1,j) - pWatcher(:,j);
    uPredLog(:,1,j) = normalizeVector(rh0);
end

[aRawSum(:,1),aFused(:,1),aRawMean(:,1),B0,Omega0,q0,rank0,eig0,cond0] = ...
    fuseTransversePointEstimates( ...
        aLocal(:,1,:),uPredLog(:,1,:),alphaWatcher,relativeRankTol);

BLog(:,:,:,1)             = B0;
omegaLog(:,:,:,1)         = Omega0;
qSharedLog(:,1,:)          = q0;
geometrySum(:,:,1)         = sum(Omega0,3);
geometryRank(1)            = rank0;
geometryEigenvalues(:,1)   = eig0;
geometryCondition(1)       = cond0;

%% EKF recursion
for k = 1:N-1
    for j = 1:Nw
        % Prediction. xp and Pp summarize all prior local information.
        xp = F*xhat(:,k,j);
        Pp = F*Plog(:,:,j,k)*F.' + Q;
        Pp = 0.5*(Pp + Pp.');

        % True relative position: used only for measurement generation.
        rhoTrue = rTrue(:,k+1) - pWatcher(:,j);

        % Prior predicted relative position: used for both the EKF Jacobian
        % and the fusion projector at time k+1.
        rh = xp(1:dim) - pWatcher(:,j);
        rr = max(norm(rh),1e-9);
        uh = rh/rr;
        uPredLog(:,k+1,j) = uh;

        if dim == 2
            %% 2-D scalar bearing measurement
            bearingTrue = atan2(rhoTrue(2),rhoTrue(1));
            z = wrapAngle(bearingTrue + sigmaBearing*randn);

            bearingHat = atan2(uh(2),uh(1));
            innov = wrapAngle(z - bearingHat);

            % dh/dr = n^T/rho, n = [-u_y;u_x].
            Hpos = [-uh(2), uh(1)]/rr;
            H = [Hpos, zeros(1,2*dim)];
            R = sigmaBearing^2;

            % Measured LOS is logged for comparison only.
            uMeasLog(:,k+1,j) = [cos(z); sin(z)];

        else
            %% 3-D azimuth-elevation measurement
            [azTrue,elTrue] = cartesianToAzEl(rhoTrue);

            zAz = wrapAngle(azTrue + sigmaAz*randn);
            zEl = clampElevation(elTrue + sigmaEl*randn);
            z = [zAz;zEl];

            dxh = rh(1);
            dyh = rh(2);
            dzh = rh(3);

            rhoXYh = max(hypot(dxh,dyh),1e-9);
            rho2h  = max(dot(rh,rh),1e-12);

            azHat = atan2(dyh,dxh);
            elHat = atan2(dzh,rhoXYh);

            innov = [ ...
                wrapAngle(z(1)-azHat);
                z(2)-elHat];

            Hpos = [ ...
                -dyh/(rhoXYh^2), ...
                 dxh/(rhoXYh^2), ...
                 0; ...
                -(dxh*dzh)/(rho2h*rhoXYh), ...
                -(dyh*dzh)/(rho2h*rhoXYh), ...
                  rhoXYh/rho2h];

            H = [Hpos, zeros(2,2*dim)];
            R = diag([sigmaAz^2,sigmaEl^2]);

            % Measured LOS is logged for comparison only.
            uMeasLog(:,k+1,j) = azElToUnitLOS(z(1),z(2));
        end

        % EKF correction.
        S = H*Pp*H.' + R;
        S = 0.5*(S + S.');
        K = (Pp*H.')/S;

        xn = xp + K*innov;

        % Joseph covariance update.
        IminusKH = eye(n)-K*H;
        Pn = IminusKH*Pp*IminusKH.' + K*R*K.';
        Pn = 0.5*(Pn + Pn.');

        xhat(:,k+1,j)   = xn;
        Plog(:,:,j,k+1) = Pn;

        % Posterior current-acceleration point estimate conditioned on the
        % complete local measurement history through time k+1.
        aLocal(:,k+1,j) = xn(2*dim+(1:dim));
    end

    % Fuse the history-conditioned local point estimates using the current
    % prior-predicted LOS geometry. No covariance is needed for this
    % equal-confidence point-estimate reconstruction.
    [aRawSum(:,k+1),aFused(:,k+1),aRawMean(:,k+1),Bk,Omegak,qk,rankk,eigk,condk] = ...
        fuseTransversePointEstimates( ...
            aLocal(:,k+1,:),uPredLog(:,k+1,:), ...
            alphaWatcher,relativeRankTol);

    BLog(:,:,:,k+1)           = Bk;
    omegaLog(:,:,:,k+1)       = Omegak;
    qSharedLog(:,k+1,:)        = qk;
    geometrySum(:,:,k+1)       = sum(Omegak,3);
    geometryRank(k+1)          = rankk;
    geometryEigenvalues(:,k+1) = eigk;
    geometryCondition(k+1)     = condk;
end

%% Local transverse/LOS acceleration-error diagnostics
transverseErrorNorm = zeros(N,Nw);
losErrorAbs         = zeros(N,Nw);

for k = 1:N
    for j = 1:Nw
        u = normalizeVector(uPredLog(:,k,j));
        Pperp = eye(dim)-u*u.';
        eLocal = aLocal(:,k,j)-aTrue(:,k);

        transverseErrorNorm(k,j) = norm(Pperp*eLocal);
        losErrorAbs(k,j)         = abs(u.'*eLocal);
    end
end

%% Package result
result = struct( ...
    'time',t, ...
    'targetPosition',rTrue, ...
    'targetVelocity',vTrue, ...
    'trueAcceleration',aTrue, ...
    'watcherPosition',pWatcher, ...
    'localState',xhat, ...
    'localCovariance',Plog, ...
    'localAccelerationPointEstimate',aLocal, ...
    'localAcceleration',aLocal, ...
    'measuredLOS',uMeasLog, ...
    'predictedLOS',uPredLog, ...
    'fusionLOS',uPredLog, ...
    'fusionLOSSource','EKF prior predicted LOS', ...
    'alphaWatcher',alphaWatcher, ...
    'sharedTransversePointEstimate',qSharedLog, ...
    'transverseInformationWeight',omegaLog, ...
    'normalizedGeometryWeight',BLog, ...
    'geometryWeight',BLog, ...
    'fusedAccelerationPointEstimate',aFused, ...
    'geometryFusion',aFused, ...
    'rawSum',aRawSum, ...
    'rawMean',aRawMean, ...
    'geometryInformationSum',geometrySum, ...
    'geometryRank',geometryRank, ...
    'geometryEigenvalues',geometryEigenvalues, ...
    'geometryCondition',geometryCondition, ...
    'transverseErrorNorm',transverseErrorNorm, ...
    'losErrorAbs',losErrorAbs, ...
    'radialErrorAbs',losErrorAbs, ...
    'seed',seed, ...
    'dimension',dim, ...
    'bearingSigmaDeg',rad2deg(sigmaBearing), ...
    'azimuthSigmaDeg',rad2deg(sigmaAz), ...
    'elevationSigmaDeg',rad2deg(sigmaEl));

%% RMSE summary
caseName = ["raw-sum";"transverse-point-fusion";"raw-mean"];
estimate = {aRawSum,aFused,aRawMean};

accelerationRMSE = zeros(3,1);
finalAccelerationRMSE = zeros(3,1);
idxFinal = max(1,round(0.9*N)):N;

for i = 1:3
    e = vecnorm(estimate{i}-aTrue,2,1);
    accelerationRMSE(i) = sqrt(mean(e.^2));
    finalAccelerationRMSE(i) = sqrt(mean(e(idxFinal).^2));
end

result.summary = table( ...
    caseName,accelerationRMSE,finalAccelerationRMSE);

fprintf('\n4-watcher %d-D angle-only local EKF point-estimate fusion\n',dim);
disp(result.summary);

if makePlots
    result.figure = plotResult(result);
end
end

function [aRawSum,aFused,aRawMean,B,Omega,qShared,geometryRank,eigValues,conditionNumber] = ...
    fuseTransversePointEstimates(aPoint,uPred,alpha,relativeRankTol)
%FUSETRANSVERSEPOINTESTIMATES Reconstruct a full acceleration point estimate.
%
% aPoint(:,:,i) is the local filtered point estimate aHat_i(k|k), which is
% conditioned on watcher i's complete measurement history through time k.
% The current prior predicted LOS selects the transverse directional
% constraint that watcher i shares:
%
%   Omega_i = alpha_i (I-uHat_i^- uHat_i^{-T}),
%   q_i     = Omega_i aHat_i(k|k).
%
% The fused current-acceleration point estimate is
%
%   aHat_f = (sum_i Omega_i)^dagger sum_i q_i.
%
% This routine computes a point estimate only. It does not claim to produce
% the fused posterior covariance.

validateattributes(alpha,{'numeric'},{'vector','numel',size(aPoint,3), ...
    'nonnegative','finite'});

dim = size(aPoint,1);
Nw  = size(aPoint,3);
alpha = alpha(:);

Omega  = zeros(dim,dim,Nw);
qShared = zeros(dim,1,Nw);
OmegaSum = zeros(dim);
qSum = zeros(dim,1);

for j = 1:Nw
    u = normalizeVector(uPred(:,1,j));
    Pperp = eye(dim)-u*u.';
    Pperp = 0.5*(Pperp+Pperp.');

    Omega(:,:,j) = alpha(j)*Pperp;
    qShared(:,:,j) = Omega(:,:,j)*aPoint(:,:,j);

    OmegaSum = OmegaSum+Omega(:,:,j);
    qSum = qSum+qShared(:,:,j);
end

[OmegaPinv,geometryRank,eigValues,conditionNumber] = ...
    symmetricPseudoInverse(OmegaSum,relativeRankTol);

aFused = OmegaPinv*qSum;

% B_i shows the final matrix contribution of watcher i:
% aHat_f = sum_i B_i aHat_i(k|k).
B = zeros(dim,dim,Nw);
for j = 1:Nw
    B(:,:,j) = OmegaPinv*Omega(:,:,j);
end

aRawSum  = sum(aPoint,3);
aRawMean = aRawSum/Nw;
end

function [Aplus,numericalRank,eigValues,conditionNumber] = ...
    symmetricPseudoInverse(A,relativeRankTol)
%SYMMETRICPSEUDOINVERSE Stable pseudoinverse for a symmetric PSD matrix.

A = 0.5*(A+A.');
[V,D] = eig(A,'vector');
[eigValues,order] = sort(real(D),'descend');
V = V(:,order);

lambdaMax = max(eigValues);
if isempty(lambdaMax) || lambdaMax <= 0
    Aplus = zeros(size(A));
    numericalRank = 0;
    conditionNumber = Inf;
    return;
end

tol = relativeRankTol*lambdaMax;
keep = eigValues > tol;
numericalRank = nnz(keep);

lambdaPlus = zeros(size(eigValues));
lambdaPlus(keep) = 1./eigValues(keep);
Aplus = V*diag(lambdaPlus)*V.';
Aplus = 0.5*(Aplus+Aplus.');

if numericalRank < size(A,1)
    conditionNumber = Inf;
else
    conditionNumber = eigValues(1)/eigValues(end);
end
end

function [az,el] = cartesianToAzEl(r)
%CARTESIANTOAZEL Convert a nonzero Cartesian vector to azimuth/elevation.
dx = r(1);
dy = r(2);
dz = r(3);

rhoXY = max(hypot(dx,dy),1e-12);
az = atan2(dy,dx);
el = atan2(dz,rhoXY);
end

function u = azElToUnitLOS(az,el)
%AZELTOUNITLOS Convert azimuth/elevation angles to a 3-D unit LOS vector.
u = [ ...
    cos(el)*cos(az);
    cos(el)*sin(az);
    sin(el)];
u = normalizeVector(u);
end

function x = wrapAngle(x)
%WRAPANGLE Wrap angles elementwise to [-pi,pi].
x = atan2(sin(x),cos(x));
end

function el = clampElevation(el)
%CLAMPELEVATION Keep elevation inside its valid chart away from the poles.
margin = 1e-8;
el = min(max(el,-pi/2+margin),pi/2-margin);
end

function u = normalizeVector(v)
%NORMALIZEVECTOR Safely normalize a vector.
nv = norm(v);
if nv < realmin
    error('Cannot normalize a zero vector.');
end
u = v/nv;
end

function fig = plotResult(r)
%PLOTRESULT Plot truth and acceleration point-estimate comparisons.

t = r.time;
a = r.trueAcceleration;

fig = figure( ...
    'Name',sprintf('%d-D angle-only EKF point-estimate fusion',r.dimension), ...
    'Color','w');

tiledlayout(r.dimension+2,1, ...
    'TileSpacing','compact', ...
    'Padding','compact');

for q = 1:r.dimension
    nexttile;
    plot(t,a(q,:),'k','LineWidth',1.3);
    hold on;
    plot(t,r.rawSum(q,:),'b');
    plot(t,r.fusedAccelerationPointEstimate(q,:),'r--','LineWidth',1.1);
    plot(t,r.rawMean(q,:),'g-.');
    grid on;
    ylabel(sprintf('a_%d',q));

    if q == 1
        legend( ...
            'truth','raw sum','transverse point fusion','raw mean', ...
            'Location','best');
    end
end

nexttile;
plot(t,vecnorm(r.rawSum-a,2,1),'b');
hold on;
plot(t,vecnorm(r.fusedAccelerationPointEstimate-a,2,1), ...
    'r--','LineWidth',1.1);
plot(t,vecnorm(r.rawMean-a,2,1),'g-.');
grid on;
ylabel('error norm');
legend('raw sum','transverse point fusion','raw mean','Location','best');

nexttile;
semilogy(t,max(r.geometryCondition,1),'k');
grid on;
xlabel('time [s]');
ylabel('cond(\Sigma \Omega_i)');
end
