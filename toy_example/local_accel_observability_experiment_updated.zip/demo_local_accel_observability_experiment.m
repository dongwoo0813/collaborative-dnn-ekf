%% DEMO_LOCAL_ACCEL_OBSERVABILITY_EXPERIMENT
% Distributed all-active test:
%   unknown constant target acceleration,
%   four independent angle-only local EKFs,
%   watchers 1 and 3 execute a finite calibrated pulse pair.

clear;
close all;
clc;

dim = 2;
makePlots = true;
simulationTime = 60;
dt = 0.05;
seed = 73;

options = struct();

% Start with the simplest acceleration case.
options.truthAccelerationMode = 'constant';
options.constantAcceleration = [0.15;0.20];

% All four watchers measure continuously.
options.activeWatcherMode = 'all';
options.activeWatcherIndex = 1;  % Retained for single/dropout modes.

% Measurement availability and maneuver participation are independent.
% Watchers 1 and 3 have substantially different LOS directions in 2-D.
options.maneuverWatcherMask = [true false true false];

% Put each local estimate on the correct initial LOS with a wrong scale.
options.initialRangeScale = [0.55,0.80,1.25,1.55];

% Finite known maneuver.
options.burnAcceleration = 2.0;
options.burnStartTime = 10.0;
options.burnDuration = 5.0;

% Angle noise and nearly constant-acceleration process model.
options.sigmaBearingDeg = 0.2;
options.sigmaJerk = 0.02;

% Downweight nonmaneuvering watchers only after the pulse begins.
options.nonManeuverFusionWeight = 0.1;

% Post-burn metrics start after the pulse pair and this settling interval.
options.postBurnSettlingTime = 10.0;

resultAll = run_local_accel_observability_experiment( ...
    dim,makePlots,simulationTime,dt,seed,options);
