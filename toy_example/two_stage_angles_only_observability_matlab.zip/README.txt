Two-stage angle-only observability study

1. run_paper_rv_observability_validation.m
   - State: [r; v]
   - Four independent angle-only local EKFs
   - Same measurement noise in no-maneuver and finite-pulse-pair cases
   - Initial estimates use the correct LOS but incorrect positive range scale
   - Intended to isolate the maneuver mechanism described by the paper

2. run_common_multisensor_accel_EKF.m
   - State: [r; v; a]
   - One common EKF using all four angle measurements in a stacked update
   - No local acceleration fusion in this benchmark
   - Intended to test whether the augmented acceleration state is estimable
     once the network geometry is used at the state-update level

3. demo_two_stage_angles_only_observability.m
   - Runs both stages with default 2-D settings

The finite maneuver is a fixed-direction pulse pair:
  +A for T_b, then -A for T_b, then coast.
It has zero final maneuver velocity and a nonzero lateral displacement.
