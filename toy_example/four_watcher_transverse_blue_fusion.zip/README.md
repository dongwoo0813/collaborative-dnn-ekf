# Four-watcher transverse BLUE acceleration fusion

Run:

```matlab
demo_four_watcher_acceleration_blue_fusion
```

The main function is:

```matlab
run_four_watcher_acceleration_blue_experiment
```

## Fusion rules

For watcher \(i\), let \(N_i\) be an orthonormal basis perpendicular to
the predicted LOS. The local partial estimate is

\[
z_i=N_i^\top\hat a_i.
\]

The code compares:

1. **Equal geometry**
   \[
   \hat a=(\sum_iN_iN_i^\top)^\dagger
   \sum_iN_iN_i^\top\hat a_i.
   \]

2. **Diagonal transverse BLUE**
   Assumes \(P_{aa,ij}=0\) for \(i\ne j\).

3. **Correlated transverse BLUE**
   Uses
   \[
   R_{ij}=N_i^\top P_{aa,ij}N_j
   \]
   and
   \[
   \hat a=(C^\top R^\dagger C)^\dagger C^\top R^\dagger z.
   \]

No heuristic weight floor, square-root weight, NIS penalty, beta blending,
low-pass filtering, mean fallback, or previous-value hold is used.

## Explicit modeling assumptions

- Watcher measurement noises are mutually independent.
- `initialCrossCovarianceMode` selects independent or common prior errors.
- `commonProcessNoiseFraction` specifies how much process noise is common
  across local filters.
- A full acceleration estimate is marked `NaN` whenever the corresponding
  information matrix is not full rank.
